<?php if (isset($component)) { $__componentOriginal210a77bdb94aed48d569cefa5d4f0521 = $component; } ?>
<?php $component = App\View\Components\Front::resolve(['title' => 'Login'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('front'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Front::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php if($errors): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($error); ?>

            <br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

    <div class="container">
        <div class="card m-auto mt-5 mb-5">
            <div class="card-header bg-blue text-white">تسجيل الدخول</div>
            <div class="card-body">
                <form method="POST" action="<?php echo e(route('login')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">البريد الإلكتروني</label>
                        <input value="" name="email" type="email" class="form-control" id="exampleInputEmail1"
                               aria-describedby="emailHelp">
                    </div>
                    <div class="mb-3">
                        <label for="exampleInputPassword1" class="form-label">كلمة المرور</label>
                        <input name="password" type="password" class="form-control" id="exampleInputPassword1">
                    </div>
                    <div class="d-grid gap-2 col-12 mx-auto">
                        <button type="submit" class="btn bg-blue text-white btn-block">تسجيل الدخول</button>
                    </div>
                </form>
            </div>
            <div class="card-footer center">
                <span class="btn btn-light text-danger">ألا تمتلك حساب</span>
                <div>
                    <a href="<?php echo e(route('register')); ?>" class="btn-small btn btn-secondary">إنشاء حساب شخصي</a>
                    <a href="/register/seller" class="btn-small btn btn-secondary">إنشاء حساب تاجر</a>
                </div>
            </div>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal210a77bdb94aed48d569cefa5d4f0521)): ?>
<?php $component = $__componentOriginal210a77bdb94aed48d569cefa5d4f0521; ?>
<?php unset($__componentOriginal210a77bdb94aed48d569cefa5d4f0521); ?>
<?php endif; ?>
<?php /**PATH D:\joulani-auto\resources\views/front/auth/login.blade.php ENDPATH**/ ?>