<?php if(session()->has('success')): ?>
    <div class="alert alert-success alert-block">
        <button type="button" class="close" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
        <strong><?php echo e(session('success')); ?></strong>
    </div>
<?php endif; ?>
<?php if(session()->has('error')): ?>
    <div class="alert alert-success alert-block">
        <button type="button" class="close" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
        <strong><?php echo e(session('error')); ?></strong>
    </div>
<?php endif; ?>
<?php if(session()->has('warning')): ?>
    <div class="alert alert-success alert-block">
        <button type="button" class="close" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
        <strong><?php echo e(session('warning')); ?></strong>
    </div>
<?php endif; ?>
<?php if(session()->has('info')): ?>
    <div class="alert alert-success alert-block">
        <button type="button" class="close" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
        <strong><?php echo e(session('info')); ?></strong>
    </div>
<?php endif; ?>
<?php /**PATH D:\joulani-auto\resources\views/layouts/flash-message.blade.php ENDPATH**/ ?>