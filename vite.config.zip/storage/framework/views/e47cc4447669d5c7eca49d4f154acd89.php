<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'data'=>'',
    'made_id'=>'',
    'mould_id'=>'',
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'data'=>'',
    'made_id'=>'',
    'mould_id'=>'',
]); ?>
<?php foreach (array_filter(([
    'data'=>'',
    'made_id'=>'',
    'mould_id'=>'',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>;
<div class="col-12">
    <div class="card mb-3">
        <div class="card-header text-white bg-blue">الشركة المصنعة</div>
        <div class="card-body">
            <div id="allMake">
                <div class="row">
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-xl-2 col-lg-2 col-md-3 col-sm-4 col-4 text-center mb-2 carMake"
                             data-id="<?php echo e($value->id); ?>">
                            <img src="<?php echo e(asset('storage/'.$value->image)); ?>" width="50"
                                 height="50"/>
                            <div><?php echo e($value->name); ?></div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="mt-1 mb-1 card-body  d-none " id="chosenCarOnAdd">
                <hr/>
                <input type="hidden" value="<?php echo e($made_id); ?>" name="made_id" id="makes_type">
                <input type="hidden" value="<?php echo e($mould_id); ?>" name="mould_id" id="made_type">
                <div class="row">
                    <div class="col-2 text-center " id="MakeImg">
                    </div>
                    <div class="col-2 text-center make_in" id="MakeName">
                    </div>
                    <div class="col-2 text-center mould_in" id="ModelName">
                    </div>
                    <div class="col-2 text-center">
                        <div class="btn btn-warning" id="deleteUserChoice"><i
                                class="fas fa-trash-alt"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="btn btn-secondary float-start" id="viewMoreMake">عرض المزيد من الشركات</div>
        </div>
    </div>
</div>
<?php /**PATH D:\joulani-auto\resources\views/components/vehicle/mades.blade.php ENDPATH**/ ?>