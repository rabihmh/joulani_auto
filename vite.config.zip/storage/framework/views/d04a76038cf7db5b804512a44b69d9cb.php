<fieldset>
    <legend><?php echo e(__('Abilities')); ?></legend>
    <?php $__currentLoopData = \Illuminate\Support\Facades\App::make('abilities'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ability_code =>$ability_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row mb-2">
            <div class="col-md-6">
                <?php echo e($ability_name); ?>

            </div>
            <div class="col-md-2">
                <input type="radio" name="abilities[<?php echo e($ability_code); ?>]"
                       value="allow" <?php if(($role_abilities[$ability_code] ?? '') == 'allow'): echo 'checked'; endif; ?> <?php echo e($checked??''); ?>>
                Allow
            </div>
            <div class="col-md-2">
                <input type="radio" name="abilities[<?php echo e($ability_code); ?>]"
                       value="deny" <?php if(($role_abilities[$ability_code] ?? '') == 'deny'): echo 'checked'; endif; ?>>Deny
            </div>
            
            
            
            
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</fieldset>
<div class="form-group">
    <button type="submit" class="btn-primary"><?php echo e($button_label ??'Save'); ?></button>
</div>
<?php /**PATH D:\joulani-auto\resources\views/admin/roles/_form.blade.php ENDPATH**/ ?>