<?php if (isset($component)) { $__componentOriginal210a77bdb94aed48d569cefa5d4f0521 = $component; } ?>
<?php $component = App\View\Components\Front::resolve(['title' => ''.e($vehicle->vehicle_name).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('front'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Front::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('breadcrumbs', null, []); ?> 
        <div class="container">
            <span typeof="v:Breadcrumb"><a property="v:title" rel="v:url"
                                           href="<?php echo e(route('front.home')); ?>">الرئيسية</a></span>
            <span class="sep">»</span>
            <span typeof="v:Breadcrumb"><a
                    property="v:title"
                    rel="v:url"
                    href="<?php echo e(route('front.vehicles.index')); ?>">المركبات</a></span>
            <span class="sep">»</span>
            <span typeof="v:Breadcrumb"
            ><span property="v:title" class="current"
                ><?php echo e($vehicle->vehicle_name); ?></span
                ></span
            >
        </div>
     <?php $__env->endSlot(); ?>
    <div class="container mt-1 mb-5">
        <div class="row">
            <div class="col-12 text-center mb-2">
                <h2><?php echo e($vehicle->vehicle_name); ?></h2>
            </div>
            <div class="col-lg-7 col-md-7 col-sm-12 col-xs-12">
                <div class="clear"></div>
                <div class="row">
                    <div class="col-12">
                        <figure>
                            <a
                                data-fancybox="single"
                                data-type="image"
                                href="<?php echo e(asset('storage/'.$vehicle->main_image)); ?>">
                                <img src="<?php echo e(asset('storage/'.$vehicle->main_image)); ?>" alt="" title=""/>
                            </a>
                        </figure>
                    </div>
                </div>
            </div>
            <div class="col-lg-5 col-md-5 col-sm-12 col-xs-12">
                <div class="row car-info">
                    <div class="col-4">
                        <div class="details-bx">
                            <img style="max-width: 70%;margin-top: -33px;margin-bottom: -26px"
                                 src="<?php echo e(asset('/Front/img/price.png')); ?>" alt="" title=""/>
                            <label>السعر</label>
                            <span><?php echo e($vehicle->price); ?></span>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="details-bx">
                            <img src="<?php echo e(asset('/Front/img/power.png')); ?>" alt="" title=""/>
                            <label>القوة</label>
                            <span><?php echo e($vehicle->power); ?></span>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="details-bx">
                            <div class="aut car-sb-img"></div>
                            <label>ناقل الحركة</label>
                            <span><?php echo e(__('vehicle.'.$vehicle->gear)); ?></span>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="details-bx">
                            <img src="<?php echo e(asset('/Front/img/fuel.png')); ?>" alt="" title=""/>
                            <label>الوقود</label>
                            <span><?php echo e(__('vehicle.'.$vehicle->fuel)); ?></span>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="details-bx">
                            <img src="<?php echo e(asset('/Front/img/date.png')); ?>" alt="" title=""/>
                            <label>سنة الإنتاج</label>
                            <span><?php echo e($vehicle->year_of_product); ?></span>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="details-bx">
                            <img src="<?php echo e(asset('/Front/img/seat.png')); ?>" alt="" title=""/>
                            <label>عدد المقاعد</label>
                            <span><?php echo e(__('vehicle.'.$vehicle->num_of_seats)); ?></span>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="details-bx">
                            <img src="<?php echo e(asset('/Front/img/hp.png')); ?>" alt="" title=""/>
                            <label>عدد الأحصنة</label>
                            <span><?php echo e($vehicle->hp); ?></span>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="details-bx">
                            <img src="<?php echo e(asset('/Front/img/distance.png')); ?>" alt="" title=""/>
                            <label>المسافة المقطوعة</label>
                            <span><?php echo e($vehicle->mileage); ?></span>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="details-bx">
                            <img src="<?php echo e(asset('/Front/img/key.png')); ?>" alt="" title=""/>
                            <label>عدد المفاتيح</label>
                            <span><?php echo e(__('vehicle.'.$vehicle->num_of_keys)); ?></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="row">
                        <?php $__currentLoopData = explode(',',$vehicle->oimg); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="other-img col-lg-2 col-md-2 col-sm-3 col-3 mb-2">
                                <a
                                    data-fancybox="single"
                                    data-type="image"
                                    href="<?php echo e(asset('storage/'.$image)); ?>">
                                    <img src="<?php echo e(asset('storage/'.$image)); ?>" alt="" title=""/>
                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="card mt-3 mb-3">
                        <div class="card-header text-white bg-blue">معلومات أخرى</div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                    <table class="table table-bordered">
                                        <tr>
                                            <td>طرق الدفع</td>
                                            <td>
                                                <?php echo \App\Facades\VehicleDataFacade::display($vehicle->payment_method); ?>

                                            </td>
                                        </tr>
                                        <tr>
                                            <td>نظام الدفع</td>
                                            <td><label
                                                    class="btn btn-light btn-sm"><?php echo e(__('vehicle.'.$vehicle->drivetrain_system)); ?></label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>فتحة سقف</td>
                                            <td>
                                                <label class="btn btn-light btn-sm"><?php echo e(__('vehicle.'.$vehicle->extra->ext_int_sunroof)); ?></label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>الزجاج</td>
                                            <td>
                                               <?php echo \App\Facades\VehicleDataFacade::display($vehicle->extra->ext_int_glass); ?>

                                            </td>
                                        </tr>
                                        <tr>
                                            <td>الشاشات</td>
                                            <td>
                                                <?php echo \App\Facades\VehicleDataFacade::display($vehicle->extra->ext_int_screens); ?>

                                            </td>
                                        </tr>
                                        <tr>
                                            <td>المقاعد</td>
                                            <td>
                                                <?php echo \App\Facades\VehicleDataFacade::display($vehicle->extra->ext_int_seats); ?>

                                            </td>
                                        </tr>
                                        <tr>
                                            <td>نوع الفرش</td>
                                            <td>
                                                <?php echo \App\Facades\VehicleDataFacade::display($vehicle->extra->ext_int_furniture); ?>

                                            </td>
                                        </tr>
                                    </table>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                    <table class="table table-bordered">
                                        <tr>
                                            <td>المقود</td>
                                            <td>
                                                <?php echo \App\Facades\VehicleDataFacade::display($vehicle->extra->ext_int_steering); ?>


                                            </td>
                                        </tr>
                                        <tr>
                                            <td>الحساسات</td>
                                            <td>
                                                <?php echo \App\Facades\VehicleDataFacade::display($vehicle->extra->ext_ext_sensors); ?>


                                            </td>
                                        </tr>
                                        <tr>
                                            <td>المرايا</td>
                                            <td>
                                                <?php echo \App\Facades\VehicleDataFacade::display($vehicle->extra->ext_ext_mirrors); ?>


                                            </td>
                                        </tr>
                                        <tr>
                                            <td>الإضاءة</td>
                                            <td>
                                                <?php echo \App\Facades\VehicleDataFacade::display($vehicle->extra->ext_ext_light); ?>


                                            </td>
                                        </tr>
                                        <tr>
                                            <td>الكاميرات</td>
                                            <td>
                                                <?php echo \App\Facades\VehicleDataFacade::display($vehicle->extra->ext_ext_cameras); ?>

                                            </td>
                                        </tr>
                                        <tr>
                                            <td>اللون الخارجي</td>
                                            <td>
                                                <div
                                                    class="btn p-3"
                                                    style="background-color: <?php echo e($vehicle->body_color); ?>;border: 1px solid"
                                                ></div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>اللون الداخلي</td>
                                            <td>
                                                <div
                                                    class="btn p-3"
                                                    style="background-color: <?php echo e($vehicle->interior_color); ?>;border: 1px solid"
                                                ></div>
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                                <table class="table table-bordered">
                                    <tr>
                                        <td>إضافات داخلية أخرى</td>
                                        <td>
                                            <?php echo \App\Facades\VehicleDataFacade::display($vehicle->extra->ext_int_other); ?>


                                        </td>
                                    </tr>
                                </table>
                                <table class="table table-bordered">
                                    <tr>
                                        <td width="25%">إضافات أخرى</td>
                                        <td>
                                            <?php echo \App\Facades\VehicleDataFacade::display($vehicle->extra->ext_gen_other); ?>


                                        </td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="card mt-3 mb-3">
                        <div class="card-header text-white bg-blue">معلومات المعلن</div>
                        <div class="card-body bg-blue-data">
                            <ul>
                                <li>
                                    <label>الإسم: </label><?php echo e($vehicle->seller->seller_name); ?>

                                </li>
                                <li>
                                    <label>رقم الهاتف: </label
                                    ><a href="tel:<?php echo e($vehicle->seller->seller_mobile); ?>" id="4682"
                                        class="call-advertiser">
                                        <?php echo e($vehicle->seller->seller_mobile); ?></a>
                                </li>
                            </ul>
                            <a href="<?php echo e(route('front.sellers.show',$vehicle->seller->id)); ?>"
                               class="btn btn-small btn-primary"
                            >عرض جميع إلإعلانات</a
                            >
                            <a
                                href="<?php echo e($vehicle->seller->seller_mobile); ?>"
                                id="4682"
                                class="btn btn-small btn-success call-advertiser"
                            >الإتصال بالمعلن</a
                            >
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="card mt-3 mb-3">
                        <div class="card-header text-white bg-blue">مشاركة</div>
                        <div class="social_share card-body">
                            <a
                                href="https://www.facebook.com/sharer/sharer.php?u=http://127.0.0.1/vehicles/1&title=Land Rover, Range Rover Vogue"
                                class="facebook hvr-pulse"
                                target="_blank"
                            ><i class="fab fa-facebook"></i
                                ></a>
                            <a
                                href="whatsapp://send?text=<?php echo e(route('front.vehicles.show',$vehicle->id)); ?>"
                                class="whatsapp hvr-pulse"
                                target="_blank"
                            ><i class="fab fa-whatsapp"></i
                                ></a>
                            <a
                                href="https://telegram.me/share/url?url=<?php echo e(route('front.vehicles.show',$vehicle->id)); ?>"
                                class="telegram hvr-pulse"
                                target="_blank"
                            ><i class="fab fa-telegram"></i
                                ></a>
                            <div class="clear"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal210a77bdb94aed48d569cefa5d4f0521)): ?>
<?php $component = $__componentOriginal210a77bdb94aed48d569cefa5d4f0521; ?>
<?php unset($__componentOriginal210a77bdb94aed48d569cefa5d4f0521); ?>
<?php endif; ?>
<?php /**PATH D:\joulani-auto\resources\views/front/vehicles/show.blade.php ENDPATH**/ ?>