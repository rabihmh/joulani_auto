<!doctype html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="utf-8">
    <meta name="description"
          content="جولاني أوتو هو موقع  لتجارة السيارات في لبنان يتضمن العديد من المميزات منها البحث بدون كتابة المواصفات والمقارنة بين المركبات">
    <meta name="keywords" content=" تطبيق لتجارة السيارات في لبنان.">
    
    <meta property="og:description"
          content="جولاني أوتو هو موقع  لتجارة السيارات في لبنان يتضمن العديد من المميزات منها البحث بدون كتابة المواصفات والمقارنة بين المركبات">
    <meta property="og:title" content=" جولاني أوتو - Joulani Auto">
    <meta property="og:type" content="articles">
    
    <meta property="og:image" content="<?php echo e(asset('Front/img/logo.png')); ?>">
    <meta name="twitter:title" content=" جولاني أوتو - Joulani Auto">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e($title); ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css"
          integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w=="
          crossorigin="anonymous" referrerpolicy="no-referrer"/>
    <link rel="stylesheet" href="<?php echo e(asset('Front/css/sumoselect.css')); ?>"/>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('Front/css/bootstrap-slider.css')); ?>"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fancyapps/ui/dist/fancybox.css"/>
    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/11.2.0/sweetalert2.min.css"/>

    <link rel="stylesheet" href="<?php echo e(asset('Front/css/style.css')); ?>"/>

    <meta name="csrf-token" content="sCqI4SS9Tc3yZWnJGOptjwM36m1DpBoFWMD5dCFV"/>
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('Front/img/logo.png')); ?>">
    <?php echo $__env->yieldPushContent('css'); ?>

</head>
<body>
    <span class="web-btn">
		<label class="line1"></label>
		<label class="line2"></label>
		<label class="line3"></label>
</span>
    <div id="menu">
        <nav class="mobileMenu">
            <a href="/" class="mobile-logo">
                <img src="<?php echo e(asset('Front/images/icons/logo-mobile.png')); ?>" alt="أوتو أند درايف" title="أوتو أند درايف"/>
            </a>
            <a href="/" class="<?php echo e(\Illuminate\Support\Facades\Request::is('/')?'active':''); ?>">الرئيسية</a>
            <a href="<?php echo e(route('front.vehicles.index')); ?>"
               class="<?php echo e(\Illuminate\Support\Facades\Request::is('vehicles')?'active':''); ?>">البحث</a>
            <a href="<?php echo e(route('front.sellers.index')); ?>"
               class="<?php echo e(Request::url() == route('front.sellers.index') ? 'active' : ''); ?>">معارض السيارات</a>
            <a href="/user/contact" class="<?php echo e(\Illuminate\Support\Facades\Request::is('user/contact')?'active':''); ?>">إتصل
                بنا</a>
            <?php if(auth()->guard('web')->check()): ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('vehicles.create')): ?>
                    <a href="<?php echo e(route('front.vehicles.create')); ?>"
                       class="<?php echo e(\Illuminate\Support\Facades\Request::is('vehicles/create')?'active':''); ?>">إضافة
                        مركبة</a>
                <?php endif; ?>
                <a href="<?php echo e(route('front.user.dashboard')); ?>"
                   class="<?php echo e(\Illuminate\Support\Facades\Request::is('userDashboard')?'active':''); ?>">حسابي</a>
                <a href="#"
                   onclick="event.preventDefault(); document.getElementById('frm-logout').submit();">
                    تسجيل الخروج
                </a>
                <form id="frm-logout" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                </form>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>" class="">تسجيل الدخول</a>
            <?php endif; ?>

        </nav>
        <div class="mobile-social mt-5 flex">
            <a href="" target="_blank" class="facebook"><i
                    class="fab fa-facebook "></i></a>
            <a href="" target="_blank" class="whatsapp"><i
                    class="fab fa-whatsapp"></i></a>
            <a href="" target="_blank" class="instagram"><i class="fas fa-phone-volume"></i></a>
            <a href="" target="_blank" class="googleplus"><i
                    class="far fa-envelope"></i></a>
        </div>
        <div class="location mt-5">
            <i class="fas fa-map-marker-alt"></i> &nbsp;عكار - المقيطع
        </div>
    </div>
    <div class="mobileLogo">
        <a href="/">
            <img src="<?php echo e(asset('Front/img/logo.png')); ?>" alt="جولاني أوتو" title="جولاني أوتو" class="mr-3"/>
        </a>
    </div>
    <header id="header">
        <div class="container">
            <nav id="nav">
                <a href="/"
                   class="<?php echo e(\Illuminate\Support\Facades\Request::is('/')?'active':''); ?>">الرئيسية</a>
                <a href="<?php echo e(route('front.vehicles.index')); ?>"
                   class="<?php echo e(\Illuminate\Support\Facades\Request::is('vehicles')?'active':''); ?>">البحث</a>
                <a href="<?php echo e(route('front.sellers.index')); ?>"
                   class="<?php echo e(Request::url() == route('front.sellers.index') ? 'active' : ''); ?>">معارض السيارات</a>
                <a href="/user/contact"
                   class="<?php echo e(\Illuminate\Support\Facades\Request::is('user/contact')?'active':''); ?>">إتصل بنا</a>
                <?php if(auth()->guard('web')->check()): ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('vehicles.create')): ?>
                        <a href="<?php echo e(route('front.vehicles.create')); ?>"
                           class="<?php echo e(\Illuminate\Support\Facades\Request::is('vehicles/create')?'active':''); ?>">إضافة
                            مركبة</a>
                    <?php endif; ?>
                    <a href="<?php echo e(route('front.user.dashboard')); ?>"
                       class="<?php echo e(\Illuminate\Support\Facades\Request::is('userDashboard')?'active':''); ?>">حسابي</a>

                    <a href="#"
                       onclick="event.preventDefault(); document.getElementById('frm-logout').submit();">
                        تسجيل الخروج
                    </a>
                    <form id="frm-logout" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
                <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>" class="">تسجيل الدخول</a>
                <?php endif; ?>
            </nav>
            <div class="logo">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
                    <path fill="#EDF0F4" fill-opacity="1"
                          d="M0,288L48,277.3C96,267,192,245,288,213.3C384,181,480,139,576,106.7C672,75,768,53,864,64C960,75,1056,117,1152,160C1248,203,1344,245,1392,266.7L1440,288L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path>
                </svg>
                <img src="<?php echo e(asset('Front/img/logo.png')); ?>" alt="" title="" class="mr-3"/>
            </div>
            <div class="clear"></div>
        </div>
    </header>


    <div class="breadcrumbs pt-2" xmlns:v="http://rdf.data-vocabulary.org/#">
        <?php echo e($breadcrumbs??""); ?>

    </div>
    <?php echo $__env->make('layouts.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo e($slot); ?>

    <?php echo e($compareBox??""); ?>

    <footer class="bg-blue">
        <div class="container p-3">
            <div class="row">
                
                
                
                
                
                
                
                
                
                

                
                
                
                
                
                
                
                
                
                
                
                
                <div class="col-12 center text-white mt-2 mb-2">
                    جميع الحقوق محفوظة لموقع جولاني أوتو @ 2022
                </div>
            </div>
        </div>
    </footer>
    <div class="mobile-footer p-1">
        <div class="col-12 center text-white mt-1 mb-1">
            جميع الحقوق محفوظة لموقع جولاني أوتو @ 2022
        </div>
    </div>


    
    <script src="https://code.jquery.com/jquery-3.6.3.min.js"
            integrity="sha256-pvPw+upLPUjgMXY0G+8O0xUf+/Im1MZjXxxgOcBQBXU=" crossorigin="anonymous"></script>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"
            integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p"
            crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js"
            integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF"
            crossorigin="anonymous"></script>
    <script src="<?php echo e(asset('Front/js/swiper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('Front/js/jquery.sumoselect.min.js')); ?>"></script>
    <script src="<?php echo e(asset('Front/js/fontawesome.min.js')); ?>"></script>
    <script src="<?php echo e(asset('Front/js/all.min.js')); ?>"></script>
    <script src="<?php echo e(asset('Front/js/bootstrap-slider.js')); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/@fancyapps/ui/dist/fancybox.umd.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/11.2.0/sweetalert2.min.js"></script>
    <script src="<?php echo e(asset('Front/js/sweet-alert.js')); ?>"></script>

    <script src="<?php echo e(asset('Front/js/myCode.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('js'); ?>

</body>

</html>
<?php /**PATH D:\joulani-auto\resources\views/components/index.blade.php ENDPATH**/ ?>