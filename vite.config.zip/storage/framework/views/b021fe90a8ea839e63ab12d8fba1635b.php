<?php if (isset($component)) { $__componentOriginal210a77bdb94aed48d569cefa5d4f0521 = $component; } ?>
<?php $component = App\View\Components\Front::resolve(['title' => 'حسابي'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('front'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Front::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startPush('css'); ?>
        <style>
            td.image-cell {
                width: 100px;
                height: 100px; /* set a fixed height */
                vertical-align: middle; /* center the image vertically */
            }

            td.image-cell img {
                max-width: 100%;
                max-height: 100%; /* set the image to fill the available height */
                object-fit: contain;
            }

        </style>
    <?php $__env->stopPush(); ?>
     <?php $__env->slot('breadcrumbs', null, []); ?> 
        <div class="container">
            <span typeof="v:Breadcrumb"><a property="v:title" rel="v:url"
                                           href="/">الرئيسية</a></span>
            <span class="sep">»</span>
            <span typeof="v:Breadcrumb"><a property="v:title" rel="v:url"
                                           href="<?php echo e(route('front.vehicles.index')); ?>">المركبات</a></span>
            <span class="sep">»</span>
            <span typeof="v:Breadcrumb"><span property="v:title" class="current">لوحة التحكم</span></span>
        </div>
     <?php $__env->endSlot(); ?>
    <div class="container mt-2 mb-5">
        <div class="row mb-2">
            <div class="col-4">
                <div class="d-grid gap-2">
                    <a href="/userDashboard" class="btn btn-sm  btn-outline-secondary ">سياراتي</a>
                </div>
            </div>
            <div class="col-4">
                <div class="d-grid gap-2">
                    <a href="#" class="btn btn-sm  btn-outline-secondary ">معلومات
                        الحساب</a>
                </div>
            </div>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('vehicles.create')): ?>
                <div class="col-4">
                    <div class="d-grid gap-2">
                        <a href="<?php echo e(route('front.vehicles.create')); ?>" class="btn btn-sm btn-outline-secondary">إضافة
                            مركبة</a>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead class="bg-blue text-white">
                <tr>
                    <th>#</th>
                    <th>صوره</th>
                    <th>إسم السيارة</th>
                    <th>تعديل</th>
                    <th>حذف</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="number-cell"><?php echo e($loop->iteration); ?></td>
                        <td class="image-cell"><img src="<?php echo e(asset('storage/'.$vehicle->main_image)); ?>"
                                                    class="vehicle-image"></td>
                        <td><?php echo e($vehicle->vehicle_name); ?></td>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('vehicles.edit')): ?>
                            <td><a class="btn btn-primary"
                                   href="<?php echo e(route('front.vehicles.edit',$vehicle->id)); ?>">تعديل</a>
                            </td>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('vehicles.delete')): ?>
                            <td><a class="btn btn-danger" id="delete-button" data-id="<?php echo e($vehicle->id); ?>">حذف</a></td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php $__env->startPush('js'); ?>
        <script>
            let csrf = "<?php echo e(csrf_token()); ?>"
            let d_btn = document.querySelectorAll('#delete-button');
            d_btn.forEach(function (btn) {
                btn.addEventListener('click', function () {
                    let id = btn.getAttribute('data-id');
                    displayAlert(id, csrf);
                })
            })
        </script>

    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal210a77bdb94aed48d569cefa5d4f0521)): ?>
<?php $component = $__componentOriginal210a77bdb94aed48d569cefa5d4f0521; ?>
<?php unset($__componentOriginal210a77bdb94aed48d569cefa5d4f0521); ?>
<?php endif; ?>
<?php /**PATH D:\joulani-auto\resources\views/front/user/userDashboard.blade.php ENDPATH**/ ?>