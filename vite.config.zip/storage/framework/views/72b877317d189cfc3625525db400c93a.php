<?php $__env->startSection('title'); ?>
    Admin -<?php echo e($vehicle->vehicle_name); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <style>
        img.active {
            border-bottom: 10px solid black;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-header'); ?>
    <!-- breadcrumb -->
    <div class="breadcrumb-header justify-content-between">
        <div class="my-auto">
            <div class="d-flex">
                <h4 class="content-title mb-0 my-auto">Vehicles</h4><span
                    class="text-muted mt-1 tx-13 mr-2 mb-0">/ <?php echo e($vehicle->vehicle_name); ?></span>
            </div>
        </div>
    </div>
    <!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- row -->
    <div class="row">
        <div class="col-lg-12">
            <h1>set Main Images</h1>
            <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <img id="img" data-image="<?php echo e($image); ?>" style="height: 300px" alt="Responsive image"
                     class="  img-thumbnail wd-100p wd-sm-200 <?php echo e($vehicle->main_image==$image?'active':''); ?> "
                     src="<?php echo e(asset('storage/'.$image)); ?>">

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <!-- row closed -->
    </div>
    <!-- Container closed -->
    </div>
    <!-- main-content closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        let imgElements = document.querySelectorAll('#img');

        imgElements.forEach(function (imgElement) {
            imgElement.addEventListener('click', function () {
                let id = <?php echo e($vehicle->id); ?>;
                let img = this.getAttribute('data-image');
                let xhr = new XMLHttpRequest();
                xhr.open('PUT', 'http://127.0.0.1:8000/admin/dashboard/vehicles/set_main_image/' + id);
                xhr.setRequestHeader('X-CSRF-TOKEN', "<?php echo e(csrf_token()); ?>");
                xhr.setRequestHeader('Content-Type', 'application/json');
                xhr.onreadystatechange = function () {
                    if (xhr.readyState === 4 && xhr.status === 200) {
                        imgElements.forEach(function (img) {
                            img.classList.remove('active')
                        });
                        this.classList.add('active');
                        alert('updated');
                    }
                }.bind(this);
                let data = JSON.stringify({image: img});
                xhr.send(data);
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\joulani-auto\resources\views/admin/vehicles/show.blade.php ENDPATH**/ ?>