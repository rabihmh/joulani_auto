<?php if (isset($component)) { $__componentOriginal210a77bdb94aed48d569cefa5d4f0521 = $component; } ?>
<?php $component = App\View\Components\Front::resolve(['title' => 'Home'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('front'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Front::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="premium-section">
        <div class="container">
            <section class="swiper-container art-blog-slider">
                <div class="section-title mb-4"><h3>مركبات مميزة</h3></div>
                <div class="swiper-wrapper">
                    <?php $__currentLoopData = $specials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('front.vehicles.show',$vehicle->id)); ?>"
                           class="car-premium-card swiper-slide hover01">
                            <figure><img
                                    src="<?php echo e(asset('storage/'.$vehicle->main_image)); ?>"
                                    alt="BMW " title=" " width="" height=""/></figure>
                            <div class="car-premium-title">
                                <h2></h2>
                            </div>
                            <div class="car-premium-info flex bg-blue">
                                <div>
                                    <h3><?php echo e($vehicle->price); ?>&nbsp;&nbsp;<i class="ml-1 fas fa-dollar-sign"></i></h3>
                                </div>
                                <div>
                                    <h3><?php echo e(__('vehicle.'.$vehicle->gear)); ?>&nbsp;<i class="ml-1 fas fa-cog"></i></h3>
                                </div>
                                <div>
                                    <h3><?php echo e($vehicle->year_of_product); ?>&nbsp;&nbsp;<i
                                            class="ml-1 far fa-calendar-alt"></i></h3>
                                </div>
                            </div>
                            <div class="swiper-overlay"></div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="art-slider-navigation">
                    <div class="art-sn-left">
                        <div class="swiper-pagination"></div>
                    </div>
                    <div class="art-sn-right">
                        <div class="art-slider-nav-frame">
                            <div class="art-slider-nav art-blog-swiper-prev"><i class="fa fa-chevron-left"></i></div>
                            <div class="art-slider-nav art-blog-swiper-next"><i class="fa fa-chevron-right"></i></div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>


    <div class="car-box">
        <div class="container">
            <div class="row" id="vehiclearea">
                <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3 col-lg-3 col-sm-6 col-xs-12">
                        <div class="car-bx car-bx-2">
                            <a class="hover01" href="<?php echo e(route('front.vehicles.show',$vehicle->id)); ?>">
                                <figure><img
                                        src="<?php echo e(asset('storage/'.$vehicle->main_image)); ?>"
                                        class="car-bx-img-top" alt="..."></figure>
                                <div class="car-bx-body">
                                    <h2 class="car-bx-title">
                                        <?php echo e($vehicle->vehicle_name); ?>

                                    </h2>
                                    <p class="car-bx-price">
                                        <i class="fas fa-dollar-sign"></i>&nbsp;&nbsp;<?php echo e($vehicle->price); ?>

                                    </p>
                                    <div class="row">
                                        <div class="col-4 min-box text-center mb-3">
                                            <div class="aut car-sb-img"></div>
                                            <label><?php echo e(__('vehicle.'.$vehicle->gear)); ?></label>
                                        </div>
                                        <div class="col-4 min-box text-center mb-3">
                                            <div class="fuel car-sb-img"></div>
                                            <label><?php echo e(__('vehicle.'.$vehicle->fuel)); ?></label>
                                        </div>
                                        <div class="col-4 min-box text-center mb-3">
                                            <div class="power car-sb-img"></div>
                                            <label><?php echo e($vehicle->power); ?></label>
                                        </div>
                                        <div class="col-4 min-box text-center mb-3">
                                            <div class="hp car-sb-img"></div>
                                            <label><?php echo e($vehicle->hp); ?> </label>
                                        </div>
                                        <div class="col-4 min-box text-center mb-3">
                                            <div class="date car-sb-img"></div>
                                            <label><?php echo e($vehicle->year_of_product); ?></label>
                                        </div>
                                        <div class="col-4 min-box text-center mb-3">
                                            <div class="distance car-sb-img"></div>
                                            <label><?php echo e($vehicle->mileage); ?></label>
                                        </div>
                                    </div>
                                </div>
                            </a>
                            <div data-id="<?php echo e($vehicle->id); ?>" data-img="<?php echo e(asset('storage/'.$vehicle->main_image)); ?>"
                                 data-name="<?php echo e($vehicle->vehicle_name); ?>"
                                 class="compareVehicle btn btn-sm btn-compare mb-2 text-white">مقارنة
                            </div>
                            <a href="<?php echo e(route('front.vehicles.show',$vehicle->id)); ?>">
                                <div class="car-more-details"> عرض المزيد
                                    <i class="fas fa-arrow-left"></i>
                                </div>
                            </a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
     <?php $__env->slot('compareBox', null, []); ?> 
        <div id="combareBox">
            <div class="page_divider_title">مقارنة المركبات<span class="float-start close-bx"><i
                        class="fas fa-times-circle"></i></span></div>
            <div class="row" id="combar-bx-show">
            </div>
            <a href="#" id="hrefCompare" class="btn btn-danger btn-sm float-start ml-2 mt-2">مقارنة</a>
        </div>
     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal210a77bdb94aed48d569cefa5d4f0521)): ?>
<?php $component = $__componentOriginal210a77bdb94aed48d569cefa5d4f0521; ?>
<?php unset($__componentOriginal210a77bdb94aed48d569cefa5d4f0521); ?>
<?php endif; ?>
<?php /**PATH D:\joulani-auto\resources\views/front/home.blade.php ENDPATH**/ ?>