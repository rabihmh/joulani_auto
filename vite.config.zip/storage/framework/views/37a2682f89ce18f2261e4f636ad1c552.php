<?php if (isset($component)) { $__componentOriginal210a77bdb94aed48d569cefa5d4f0521 = $component; } ?>
<?php $component = App\View\Components\Front::resolve(['title' => 'Register'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('front'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Front::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="container">
        <div class="card m-auto mb-5">
            <div class="card-header bg-dark text-white">إنشاء حساب شخصي</div>
            <div class="card-body">
                <?php if($errors): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($error); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <form method="POST" action="<?php echo e(route('register')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="table-responsive">
                        <table class="table table-bordered">

                            <tr>
                                <td>الإسم</td>
                                <td>
                                    <input
                                        name="name"
                                        value=""
                                        type="text"
                                        class="form-control"
                                        placeholder=" الإسم "
                                    />
                                </td>
                            </tr>
                            <tr>
                                <td>رقم الموبايل</td>
                                <td>
                                    <input
                                        name="phone"
                                        value=""
                                        type="tel"
                                        class="form-control"
                                        placeholder=" رقم الموبايل "
                                    />
                                </td>
                            </tr>
                            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.regions','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('regions'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                            <tr>
                                <td>البريد الإلكتروني</td>
                                <td>
                                    <input
                                        value=""
                                        name="email"
                                        type="email"
                                        class="form-control"
                                        placeholder="البريد الإلكتروني"
                                    />
                                </td>
                            </tr>
                            <tr>
                                <td>كلمة المرور</td>
                                <td>
                                    <input
                                        name="password"
                                        type="password"
                                        class="form-control"
                                        placeholder="كلمة المرور"
                                    />
                                </td>
                            </tr>
                            <tr>
                                <td>تأكيد كلمة المرور</td>
                                <td>
                                    <input
                                        name="password_confirm"
                                        type="password"
                                        class="form-control"
                                        placeholder="تأكيد كلمة المرور"
                                    />
                                </td>
                            </tr>
                        </table>
                    </div>
                    <div class="d-grid gap-2 col-12 mx-auto">
                        <button type="submit" class="btn bg-blue text-white btn-block">
                            إنشاء حساب
                        </button>
                    </div>
                </form>
            </div>
            <div class="card-footer">
                <span class="btn btn-light text-danger"> تمتلك حساب</span>
                <div class="flex">
                    <a href="<?php echo e(route('login')); ?>" class="btn-small btn btn-secondary">تسجيل الدخول</a>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal210a77bdb94aed48d569cefa5d4f0521)): ?>
<?php $component = $__componentOriginal210a77bdb94aed48d569cefa5d4f0521; ?>
<?php unset($__componentOriginal210a77bdb94aed48d569cefa5d4f0521); ?>
<?php endif; ?>
<?php /**PATH D:\joulani-auto\resources\views/front/auth/register.blade.php ENDPATH**/ ?>