<?php $__env->startSection('title'); ?>
    Admin - Roles
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-header'); ?>
    <!-- breadcrumb -->
    <div class="breadcrumb-header justify-content-between">
        <div class="my-auto">
            <div class="d-flex">
                <h4 class="content-title mb-0 my-auto">Roles</h4><span
                    class="text-muted mt-1 tx-13 mr-2 mb-0">/ All</span>
            </div>
        </div>
    </div>
    <!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="mb-5">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create','App\Models\Role')): ?>
            <a href="<?php echo e(route('admin.roles.create')); ?>" class="btn btn-sm btn-outline-primary mx-auto">Add
                Roles</a>
        <?php endif; ?>

    </div>
    <!-- row -->
    <table class="table">
        <thead>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Created At</th>
            <th colspan="2">Options</th>
        </tr>
        </thead>
        <tbody>
        <?php
            $i=0;
        ?>
        <?php $__empty_1 = true; $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

            <tr>
                <td><?php echo e($i+=1); ?></td>
                <td><a href="<?php echo e(route('admin.roles.show',$role->id)); ?>"><?php echo e($role->name); ?></a></td>
                <td><?php echo e($role->created_at); ?></td>

                    <td>
                        <a href="<?php echo e(route('admin.roles.edit',$role->id)); ?>"
                           class="btn btn-sm btn-outline-success">Edit</a>
                    </td>
                    <td>
                        <form action="<?php echo e(route('admin.roles.destroy',$role->id)); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <!--Form method spoofing-->
                            
                            <?php echo method_field('delete'); ?>
                            <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
                        </form>
                    </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td class="text-center text-danger text-lg text-bold" colspan="4">No roles defined</td>
            </tr>
        <?php endif; ?>
        </tbody>
    </table>
    <div class="text-center">
        <?php echo e($roles->withQueryString()->links()); ?>

    </div>
    <!-- row closed -->
    </div>
    <!-- Container closed -->
    </div>
    <!-- main-content closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\joulani-auto\resources\views/admin/roles/index.blade.php ENDPATH**/ ?>