<tr>
    <td>المنطقة</td>
    <td>
        <?php
            $regions=\App\Models\Region::select('id','name')->get();
        ?>
        <select class="form-control" name="region_id">
            <option value="">الرجاء إختيار المدينة</option>

            <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($region->id); ?>"><?php echo e($region->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </td>
</tr>
<?php /**PATH D:\joulani-auto\resources\views/components/regions.blade.php ENDPATH**/ ?>