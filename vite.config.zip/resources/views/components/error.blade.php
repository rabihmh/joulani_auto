@props(['name'])
@error($name)
<div class="alert alert-danger">{{$message}}</div>
@enderror
