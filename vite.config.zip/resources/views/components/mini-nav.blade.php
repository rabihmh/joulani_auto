<div class="row mb-2">
    <div class="col-4">
        <div class="d-grid gap-2">
            <a href="" class="btn btn-sm  btn-outline-secondary ">سياراتي</a>
        </div>
    </div>
    <div class="col-4">
        <div class="d-grid gap-2">
            <a href="/user/profile/edit" class="btn btn-sm  btn-secondary ">معلومات الحساب</a>
        </div>
    </div>
    <div class="col-4">
        <div class="d-grid gap-2">
            <a href="/add/car" class="btn btn-sm btn-outline-secondary">إضافة مركبة</a>
        </div>
    </div>
</div>
