<?php
return [
    'mades.view' => __('View Mades'),
    'mades.create' => 'Create Mades',
    'mades.edit' => 'Edit Mades',
    'mades.delete' => 'delete Mades',

    'moulds.view' => 'View Moulds',
    'moulds.create' => 'Create Moulds',
    'moulds.edit' => 'Edit Moulds',
    'moulds.delete' => 'Delete Moulds',

    'vehicles.view' => 'View Vehicles',
    'vehicles.create' => 'Create Vehicles',
    'vehicles.edit' => 'Edit Vehicles',
    'vehicles.delete' => 'Delete Vehicles',

    'users.view' => 'View Users',
    'users.create' => 'Create Users',
    'users.edit' => 'Edit Users',
    'users.delete' => 'Delete Users',

    'sellers.view' => 'View Sellers',
    'sellers.create' => 'Create Sellers',
    'sellers.edit' => 'Edit Sellers',
    'sellers.delete' => 'Delete Sellers',
];
